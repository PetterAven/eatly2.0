import { cn, isSameUrl, resolveUrl } from '@/lib/utils';
import { edit as editAppearance } from '@/routes/appearance';
import { edit } from '@/routes/profile';
import { show } from '@/routes/two-factor';
import { edit as editPassword } from '@/routes/user-password';
import { type NavItem } from '@/types';
import { Link, router } from '@inertiajs/react';
import { LogOut, Menu, X } from 'lucide-react';
import { type PropsWithChildren, useState } from 'react';

const settingsNavItems: NavItem[] = [
    { title: 'Perfil', href: edit(), icon: null },
    { title: 'Contraseña', href: editPassword(), icon: null },
    { title: 'Verificación en dos pasos', href: show(), icon: null },
    { title: 'Apariencia', href: editAppearance(), icon: null },
];

export default function EatlySettingsLayout({
    children,
    title = 'Ajustes',
    description = 'Administra tu perfil y la configuración de tu cuenta',
}: PropsWithChildren<{ title?: string; description?: string }>) {
    const [menuOpen, setMenuOpen] = useState(false);

    // Evita renderizar dependencias de window en SSR
    if (typeof window === 'undefined') {
        return null;
    }

    const currentPath = window.location.pathname;

    return (
        <div className="flex min-h-screen flex-col bg-gray-50 font-sans text-gray-900">
            {/* Navbar unificado con la identidad de marca (igual que Dashboard/Historial) */}
            <header className="sticky top-0 z-40 flex items-center justify-between border-b border-gray-100 bg-white px-6 py-3.5 shadow-sm">
                <div className="flex items-center space-x-3">
                    {/* Menú hamburguesa pequeño con las secciones de Ajustes */}
                    <div className="relative">
                        <button
                            onClick={() => setMenuOpen((v) => !v)}
                            className="rounded-xl p-2 text-gray-700 transition hover:bg-gray-100 focus:outline-none"
                            aria-label="Abrir menú de ajustes"
                        >
                            {menuOpen ? (
                                <X className="h-5 w-5" />
                            ) : (
                                <Menu className="h-5 w-5" />
                            )}
                        </button>

                        {menuOpen && (
                            <div className="absolute top-full left-0 z-50 mt-2 w-56 overflow-hidden rounded-2xl border border-gray-100 bg-white py-1.5 shadow-xl">
                                {settingsNavItems.map((item, index) => {
                                    const active = isSameUrl(
                                        currentPath,
                                        item.href,
                                    );
                                    return (
                                        <Link
                                            key={`${resolveUrl(item.href)}-${index}`}
                                            href={item.href}
                                            onClick={() =>
                                                setMenuOpen(false)
                                            }
                                            className={cn(
                                                'block px-4 py-2.5 text-xs font-bold text-gray-700 transition hover:bg-orange-50 hover:text-[#FF5722]',
                                                active &&
                                                    'bg-orange-50 text-[#FF5722]',
                                            )}
                                        >
                                            {item.title}
                                        </Link>
                                    );
                                })}
                            </div>
                        )}
                    </div>

                    <Link href="/dashboard" className="flex items-center gap-2">
                        <span className="text-2xl font-black tracking-tight text-gray-900">
                            Eatly <span className="text-[#FF5722]">Eats</span> 🐴
                        </span>
                    </Link>
                </div>

                <div className="flex items-center space-x-3">
                    <Link
                        href="/dashboard"
                        className="flex items-center gap-1.5 rounded-2xl px-3.5 py-2.5 text-xs font-extrabold text-gray-700 transition duration-200 hover:bg-orange-50 hover:text-[#FF5722]"
                    >
                        🍽️ Menú / Catálogo
                    </Link>

                    <Link
                        href="/historial"
                        className="flex items-center gap-1.5 rounded-2xl px-3.5 py-2.5 text-xs font-extrabold text-gray-700 transition duration-200 hover:bg-orange-50 hover:text-[#FF5722]"
                    >
                        📋 Mis Pedidos
                    </Link>

                    <button
                        onClick={() => router.post('/logout')}
                        className="flex items-center gap-1 rounded-2xl px-3 py-2 text-xs font-bold text-red-600 transition duration-200 hover:bg-red-50"
                    >
                        <LogOut className="h-3.5 w-3.5" /> Salir
                    </button>
                </div>
            </header>

            <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-8 pb-24">
                {/* Banner con identidad de marca, igual estilo que el resto de la app */}
                <div className="relative mb-8 overflow-hidden rounded-3xl bg-gradient-to-r from-orange-500 to-red-600 p-6 text-white shadow-xl">
                    <div className="relative z-10">
                        <span className="mb-2 inline-block rounded-full bg-white/25 px-3 py-1 text-[10px] font-black tracking-widest text-white uppercase backdrop-blur-md">
                            ⚙️ Configuración
                        </span>
                        <h1 className="text-2xl font-black tracking-tight lg:text-3xl">
                            {title}
                        </h1>
                        <p className="mt-1 text-sm font-medium text-white/90">
                            {description}
                        </p>
                    </div>
                </div>

                <div className="space-y-8 rounded-3xl border border-gray-100 bg-white p-6 shadow-sm">
                    {children}
                </div>
            </main>
        </div>
    );
}
