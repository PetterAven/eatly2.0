import HeadingSmall from '@/components/heading-small';
import TwoFactorRecoveryCodes from '@/components/two-factor-recovery-codes';
import TwoFactorSetupModal from '@/components/two-factor-setup-modal';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useTwoFactorAuth } from '@/hooks/use-two-factor-auth';
import EatlySettingsLayout from '@/layouts/settings/eatly-settings-layout';
import { disable, enable } from '@/routes/two-factor';
import { Form, Head } from '@inertiajs/react';
import { ShieldBan, ShieldCheck } from 'lucide-react';
import { useState } from 'react';

interface TwoFactorProps {
    requiresConfirmation?: boolean;
    twoFactorEnabled?: boolean;
}

export default function TwoFactor({
    requiresConfirmation = false,
    twoFactorEnabled = false,
}: TwoFactorProps) {
    const {
        qrCodeSvg,
        hasSetupData,
        manualSetupKey,
        clearSetupData,
        fetchSetupData,
        recoveryCodesList,
        fetchRecoveryCodes,
        errors,
    } = useTwoFactorAuth();
    const [showSetupModal, setShowSetupModal] = useState<boolean>(false);

    return (
        <EatlySettingsLayout
            title="Verificación en dos pasos"
            description="Administra la verificación en dos pasos de tu cuenta"
        >
            <Head title="Verificación en dos pasos - Eatly UPP" />
            <div className="space-y-6">
                <HeadingSmall
                    title="Verificación en dos pasos"
                    description="Administra la configuración de verificación en dos pasos de tu cuenta"
                />
                {twoFactorEnabled ? (
                    <div className="flex flex-col items-start justify-start space-y-4">
                        <Badge variant="default">Activada</Badge>
                        <p className="text-muted-foreground">
                            Con la verificación en dos pasos activada, se te
                            pedirá un código seguro y aleatorio al iniciar
                            sesión, el cual puedes obtener desde la app TOTP
                            en tu teléfono.
                        </p>

                        <TwoFactorRecoveryCodes
                            recoveryCodesList={recoveryCodesList}
                            fetchRecoveryCodes={fetchRecoveryCodes}
                            errors={errors}
                        />

                        <div className="relative inline">
                            <Form {...disable.form()}>
                                {({ processing }) => (
                                    <Button
                                        variant="destructive"
                                        type="submit"
                                        disabled={processing}
                                    >
                                        <ShieldBan /> Desactivar 2FA
                                    </Button>
                                )}
                            </Form>
                        </div>
                    </div>
                ) : (
                    <div className="flex flex-col items-start justify-start space-y-4">
                        <Badge variant="destructive">Desactivada</Badge>
                        <p className="text-muted-foreground">
                            Al activar la verificación en dos pasos, se te
                            pedirá un código seguro al iniciar sesión. Este
                            código se obtiene desde una app TOTP en tu
                            teléfono.
                        </p>

                        <div>
                            {hasSetupData ? (
                                <Button
                                    onClick={() => setShowSetupModal(true)}
                                >
                                    <ShieldCheck />
                                    Continuar configuración
                                </Button>
                            ) : (
                                <Form
                                    {...enable.form()}
                                    onSuccess={() =>
                                        setShowSetupModal(true)
                                    }
                                >
                                    {({ processing }) => (
                                        <Button
                                            type="submit"
                                            disabled={processing}
                                        >
                                            <ShieldCheck />
                                            Activar 2FA
                                        </Button>
                                    )}
                                </Form>
                            )}
                        </div>
                    </div>
                )}

                <TwoFactorSetupModal
                    isOpen={showSetupModal}
                    onClose={() => setShowSetupModal(false)}
                    requiresConfirmation={requiresConfirmation}
                    twoFactorEnabled={twoFactorEnabled}
                    qrCodeSvg={qrCodeSvg}
                    manualSetupKey={manualSetupKey}
                    clearSetupData={clearSetupData}
                    fetchSetupData={fetchSetupData}
                    errors={errors}
                />
            </div>
        </EatlySettingsLayout>
    );
}
