import { Head } from '@inertiajs/react';

import AppearanceTabs from '@/components/appearance-tabs';
import HeadingSmall from '@/components/heading-small';

import EatlySettingsLayout from '@/layouts/settings/eatly-settings-layout';

export default function Appearance() {
    return (
        <EatlySettingsLayout
            title="Apariencia"
            description="Configura la apariencia de tu cuenta"
        >
            <Head title="Ajustes de apariencia - Eatly UPP" />

            <div className="space-y-6">
                <HeadingSmall
                    title="Ajustes de apariencia"
                    description="Actualiza la configuración de apariencia de tu cuenta"
                />
                <AppearanceTabs />
            </div>
        </EatlySettingsLayout>
    );
}
